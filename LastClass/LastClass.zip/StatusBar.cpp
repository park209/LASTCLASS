
#include "StatusBar.h"

StatusBar::StatusBar() {
}

StatusBar::StatusBar(const StatusBar& source) {
}

StatusBar::~StatusBar() {
}