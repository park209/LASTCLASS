//Text.cpp 
#include "Text.h"

Text::Text(Long cpacity) : TextComposite(cpacity) {
	this->capacity = cpacity;
	this->length = 0;
}
Text::~Text() {
}

Text::Text(const Text& source) {
	this->textComponents = source.textComponents;


	Long i = 0;
	while (i < source.length) {
		this->textComponents.Modify(i, (const_cast<Text&>(source)).textComponents[i]->Clone());
		i++;
	}
	this->capacity = source.capacity;
	this->length = source.length;
}
Long Text::Add(Row *row) {
	Long index;

	if (this->length < this->capacity) {
		index = this->textComponents.Store(this->length, row->Clone());
	}
	else {
		index = this->textComponents.AppendFromRear(row->Clone());
		this->capacity++;
	}
	this->length++;
	return index;
}

Long Text::Add(TextComponent *textComponent) {
	Long index;

	if (this->length < this->capacity) {
		index = this->textComponents.Store(this->length, textComponent);
	}
	else {
		index = this->textComponents.AppendFromRear(textComponent);
		this->capacity++;
	}
	this->length++;
	return index;
}

Row* Text::GetAt(Long index) {
	return dynamic_cast<Row*>(this->textComponents[index]);
}

TextComponent*  Text::Clone() const {
	return new Text(*this);
}

Row* Text::operator[] (Long index) {
	return dynamic_cast<Row*>(this->textComponents[index]);
}


Text& Text::operator= (const Text& source) {
	Long i = 0;
	this->textComponents = source.textComponents;

	while (i < source.length) {
		this->textComponents.Modify(i, (const_cast<Text&>(source)).textComponents.GetAt(i)->Clone());
		i++;
	}
	this->capacity = source.capacity;
	this->length = source.length;
	return *this;
}

#include <iostream>
using namespace std;
#include "SingleByteCharacter.h"
#include "DoubleByteCharacter.h"
#include "Character.h"
int main(int argc, char* argv[]) {
	Text *text = new Text;
	Row *row = new Row;
	Long index1;
	Long index = text->Add(row);
	DoubleByteCharacter *testDouble = new DoubleByteCharacter("��");
	DoubleByteCharacter *testDouble1 = new DoubleByteCharacter("��");
	DoubleByteCharacter *testDouble2 = new DoubleByteCharacter("��");

	SingleByteCharacter *single1 = new SingleByteCharacter('A');
	SingleByteCharacter *single2 = new SingleByteCharacter('B');
	SingleByteCharacter *single3 = new SingleByteCharacter('C');
	index1=text[index].Add(testDouble);
	cout << text->GetAt(index)->GetAt(index)->PrintText() << endl;
	text[index].Add(testDouble1);
	text[index].Add(testDouble2);

	text[index].Add(single1);
	text[index].Add(single2);
	text[index].Add(single3);



	
	Long length = text[index].GetLength();
	Long i = 0;

	while (i < length) {
		Character *char1 = text->GetAt(index)->GetAt(i);
		i++;
	}



	//if (dynamic_cast<SingleByteCharacter*>(text[0].GetAt(0))) {
	//	cout << "single" << endl;
	//	cout << dynamic_cast<SingleByteCharacter*>(row[0].GetAt(0))->GetCharacter() << endl;
	//}
	//else{
	//	cout << "double" << endl;
	//	cout << dynamic_cast<DoubleByteCharacter*>(row[0].GetAt(0))->GetCharacters()<< endl;
	//}

	return 0;

}