#pragma once
#ifndef _SINGLEBYTECHARACTER_H
#define _SINGLEBYTECHARACTER_H
#include "Character.h"


class SingleByteCharacter :public Character {
public:
	SingleByteCharacter();
	SingleByteCharacter(char character);
	SingleByteCharacter(const SingleByteCharacter& source);
	 ~SingleByteCharacter();
	virtual Character* Clone() const ;
	SingleByteCharacter& operator=(const SingleByteCharacter& sourcce);
	//string GetCharacter()const;
	char GetCharacter()const;
private:
	char character;
};
inline char SingleByteCharacter::GetCharacter()const {
	return this->character;
}
//inline string SingleByteCharacter::GetCharacter()const {
//	return const_cast<string>(this->character);
//}
#endif // !_SINGLEBYTECHARACTER_H

