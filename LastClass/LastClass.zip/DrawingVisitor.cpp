//DrawingVisitor.cpp

#include"DrawingVisitor.h"
#include "Class.h"

#include "Generalization.h"
#include "Realization.h"
#include "Dependency.h"
#include "Association.h"
#include "DirectedAssociation.h"
#include "Aggregation.h"
#include "Aggregations.h"
#include "Composition.h"
#include "Compositions.h"
#include "Template.h"
#include <iostream>
using namespace std;

DrawingVisitor::DrawingVisitor() {
}

void DrawingVisitor::Visit(Class *object, CDC* cPaintDc) {

	Long x = object->GetX();
	Long  y = object->GetY();;
	Long width = object->GetWidth();
	Long height = object->GetHeight();

	cout << "   Class �� �׸���" << endl;
	
	cPaintDc->Rectangle(x, y, x + width, y + height);
}
void DrawingVisitor::Visit(Line *line, CDC* cPaintDc) {
	Long x = line->GetX();
	Long  y = line->GetY();;
	Long width = line->GetWidth();

	cout << "   Line �� �׸���" << endl;
	
	cPaintDc->MoveTo(x, y);
	cPaintDc->LineTo(x + width, y);
}

void DrawingVisitor::Visit(SingleByteCharacter *singleByteCharacter, CDC* cPaintDc) {
}

void DrawingVisitor::Visit(DoubleByteCharacter *doubleByteCharacter, CDC* cPaintDc) {
}


void DrawingVisitor::Visit(Generalization *generalization, CDC* cPaintDc) {

	Long startX = generalization->GetX();
	Long  startY = generalization->GetY();;
	Long endX = generalization->GetWidth();
	Long endY = generalization->GetHeight();
	//cout << "�Ϲ�ȭ���" << " " << x << " " << y << " " << width << " " << height <<  endl;

	cPaintDc->MoveTo(startX, startY);
	cPaintDc->LineTo(endX, endY);

	CBrush white(RGB(255, 255, 255));
	CBrush myBrush;
	myBrush.CreateSolidBrush(RGB(255, 255, 255));
	CBrush *oldBrush = cPaintDc->SelectObject(&myBrush);

	double degree = atan2(endX - startX, startY - endY); // ����

	double distance = sqrt(pow(endX - startX, 2) + pow(startX - endY, 2));
	// ��Ʈ�ȿ� = ��Ʈ(����(
	double dX = (endX) - (15 * (endX - startX) / distance); //�ڷ� �� ������ x
	double dY = (endY) + (15 * (startY - endY) / distance); //�ڷ� �� ������ y

																					  // ���� ����

	CPoint pts[3];

	pts[0].x = (endX); //���콺 ������ġ ��
	pts[0].y = (endY);

	pts[1].x = static_cast<LONG>(dX - 15 * cos(degree)); // ����
	pts[1].y = static_cast<LONG>(dY - 15 * sin(degree));

	pts[2].x = static_cast<LONG>(dX + 15 * cos(degree)); // �Ʒ���
	pts[2].y = static_cast<LONG>(dY + 15 * sin(degree));

	cPaintDc->SelectObject(&white);
	cPaintDc->Polygon(pts, 3);
	cPaintDc->SelectObject(oldBrush);
	myBrush.DeleteObject();
}

void DrawingVisitor::Visit(Realization *realization, CDC* cPaintDc) {

	Long startX = realization->GetX();
	Long  startY= realization->GetY();;
	Long endX = realization->GetWidth();
	Long endY = realization->GetHeight();
	//cout << "��üȭ���" << " " << x << " " << y << " " << width << " " << height << endl;

	CPen pen;
	pen.CreatePen(PS_DOT, 1, RGB(0, 0, 0));
	CPen *oldPen = cPaintDc->SelectObject(&pen);
	cPaintDc->SetBkMode(TRANSPARENT);
	cPaintDc->MoveTo(startX, startY);
	cPaintDc->LineTo(endX, endY);
	cPaintDc->SelectObject(oldPen);
	pen.DeleteObject();

	CBrush white(RGB(255, 255, 255));
	CBrush myBrush;
	myBrush.CreateSolidBrush(RGB(255, 255, 255));
	CBrush *oldBrush = cPaintDc->SelectObject(&myBrush);

	double degree = atan2(endX - startX, startY - endY); // ����

	double distance = sqrt(pow(endX - startX, 2) + pow(startY - endY, 2));
	// ��Ʈ�ȿ� = ��Ʈ(����(
	double dX = (endX) - (15 * (endX - startX) / distance); //�ڷ� �� ������ x
	double dY = (endY) + (15 * (startY - endY) / distance); //�ڷ� �� ������ y

																					  // ���� ����

	CPoint pts[3];

	pts[0].x = endX; //���콺 ������ġ ��
	pts[0].y = endY;

	pts[1].x = static_cast<LONG>(dX - 15 * cos(degree)); // ����
	pts[1].y = static_cast<LONG>(dY - 15 * sin(degree));

	pts[2].x = static_cast<LONG>(dX + 15 * cos(degree)); // �Ʒ���
	pts[2].y = static_cast<LONG>(dY + 15 * sin(degree));

	cPaintDc->SelectObject(&white);
	cPaintDc->Polygon(pts, 3);
	cPaintDc->SelectObject(oldBrush);
	myBrush.DeleteObject();
}

void DrawingVisitor::Visit(Dependency *dependency, CDC* cPaintDc) {

	Long startX = dependency->GetX();
	Long  startY = dependency->GetY();;
	Long endX = dependency->GetWidth();
	Long endY = dependency->GetHeight();
	//cout << "���� ���" << " " << x << " " << y << " " << width << " " << height << endl;

	CPen pen;
	pen.CreatePen(PS_DOT, 1, RGB(0, 0, 0));
	CPen *oldPen = cPaintDc->SelectObject(&pen);
	cPaintDc->SetBkMode(TRANSPARENT);
	cPaintDc->MoveTo(startX, startY);
	cPaintDc->LineTo(endX, endY);
	cPaintDc->SelectObject(oldPen);
	pen.DeleteObject();

	double degree = atan2(endX - startX, startY - endY); // ����

	double distance = sqrt(pow(endX - startX, 2) + pow(startY - endY, 2));
	// ��Ʈ�ȿ� = ��Ʈ(����(
	double dX = (endX) - (15 * (endX - startX) / distance); //�ڷ� �� ������ x
	double dY = (endY) + (15 * (startY - endY) / distance); //�ڷ� �� ������ y

																					  // ���� ����

	CPoint pts[3];

	pts[0].x = endX; //���콺 ������ġ ��
	pts[0].y = endY;

	pts[1].x = static_cast<LONG>(dX - 15 * cos(degree)); // ����
	pts[1].y = static_cast<LONG>(dY - 15 * sin(degree));

	pts[2].x = static_cast<LONG>(dX + 15 * cos(degree)); // �Ʒ���
	pts[2].y = static_cast<LONG>(dY + 15 * sin(degree));

	cPaintDc->MoveTo(pts[0].x, pts[0].y);
	cPaintDc->LineTo(pts[1].x, pts[1].y);

	cPaintDc->MoveTo(pts[0].x, pts[0].y);
	cPaintDc->LineTo(pts[2].x, pts[2].y);
}

void DrawingVisitor::Visit(Association *association, CDC* cPaintDc) {

	Long startX = association->GetX();
	Long startY = association->GetY();;
	Long endX = association->GetWidth();
	Long endY = association->GetHeight();
	//cout << "����ȭ���" << " " << x << " " << y << " " << width << " " << height << endl;

	cPaintDc->MoveTo(startX, startY);
	cPaintDc->LineTo(endX, endY);
}

void DrawingVisitor::Visit(DirectedAssociation *directedAssociation, CDC* cPaintDc) {

	Long startX = directedAssociation->GetX();
	Long  startY = directedAssociation->GetY();;
	Long endX = directedAssociation->GetWidth();
	Long endY = directedAssociation->GetHeight();
	//cout << "�����������" << " " << x << " " << y << " " << width << " " << height << endl;

	cPaintDc->MoveTo(startX, startY);
	cPaintDc->LineTo(endX, endY);

	double degree = atan2(endX - startX, startY - endY); // ����

	double distance = sqrt(pow(endX - startX, 2) + pow(startY - endY, 2));
	// ��Ʈ�ȿ� = ��Ʈ(����(
	double dX = (endX) - (15 * (endX - startX) / distance); //�ڷ� �� ������ x
	double dY = (endY) + (15 * (startY - endY) / distance); //�ڷ� �� ������ y

																					  // ���� ����

	CPoint pts[3];

	pts[0].x = endX; //���콺 ������ġ ��
	pts[0].y = endY;

	pts[1].x = static_cast<LONG>(dX - 15 * cos(degree)); // ����
	pts[1].y = static_cast<LONG>(dY - 15 * sin(degree));

	pts[2].x = static_cast<LONG>(dX + 15 * cos(degree)); // �Ʒ���
	pts[2].y = static_cast<LONG>(dY + 15 * sin(degree));

	cPaintDc->MoveTo(pts[0].x, pts[0].y);
	cPaintDc->LineTo(pts[1].x, pts[1].y);

	cPaintDc->MoveTo(pts[0].x, pts[0].y);
	cPaintDc->LineTo(pts[2].x, pts[2].y);
}

void DrawingVisitor::Visit(Aggregation *aggregation, CDC* cPaintDc) {

	Long  startX = aggregation->GetX();
	Long  startY = aggregation->GetY();;
	Long endX = aggregation->GetWidth();
	Long endY = aggregation->GetHeight();
	//cout << "�������" << " " << x << " " << y << " " << width << " " << height << endl;

	cPaintDc->MoveTo(startX, startY);
	cPaintDc->LineTo(endX, endY);

	CBrush white(RGB(255, 255, 255));
	CBrush myBrush;
	myBrush.CreateSolidBrush(RGB(255, 255, 255));
	CBrush *oldBrush = cPaintDc->SelectObject(&myBrush);

	double degree = atan2(endX - startX, startY - endY); // ����

	double distance = sqrt(pow(endX - startX, 2) + pow(startY - endY, 2));

	double dX = (startX) + (15 * (endX - startX) / distance); //�ڷ� �� ������ x
	double dY = (startY) - (15 * (startY - endY) / distance); //�ڷ� �� ������ y

	double dX2 = (startX) - ((endX - startX) / distance);
	double dY2 = (startY) + ((startY - endY) / distance);

	CPoint pts2[4];

	pts2[0].x = static_cast<LONG>(dX - 15 * cos(degree)); // ����
	pts2[0].y = static_cast<LONG>(dY - 15 * sin(degree));

	pts2[1].x = static_cast<LONG>(dX2); //���콺 ó�� ��
	pts2[1].y = static_cast<LONG>(dY2);

	pts2[2].x = static_cast<LONG>(dX + 15 * cos(degree)); // �Ʒ���
	pts2[2].y = static_cast<LONG>(dY + 15 * sin(degree));

	pts2[3].x = static_cast<LONG>(dX) + static_cast<LONG>(15 * (endX - startX) / distance); // ����
	pts2[3].y = static_cast<LONG>(dY) - static_cast<LONG>(15 * (startY - endY) / distance);

	cPaintDc->SelectObject(&white);
	cPaintDc->Polygon(pts2, 4);
	cPaintDc->SelectObject(oldBrush);
	myBrush.DeleteObject();
}

void DrawingVisitor::Visit(Aggregations *aggregations, CDC* cPaintDc) {

	Long startX = aggregations->GetX();
	Long  startY = aggregations->GetY();;
	Long endX = aggregations->GetWidth();
	Long endY = aggregations->GetHeight();
	//cout << "���տ������" << " " << x << " " << y << " " << width << " " << height << endl;

	cPaintDc->MoveTo(startX, startY);
	cPaintDc->LineTo(endX, endY);

	CBrush white(RGB(255, 255, 255));
	CBrush myBrush;
	myBrush.CreateSolidBrush(RGB(255, 255, 255));
	CBrush *oldBrush = cPaintDc->SelectObject(&myBrush);

	double degree = atan2(endX - startX, startY - endY); // ����

	double distance = sqrt(pow(endX - startX, 2) + pow(startY - endY, 2));
	// ��Ʈ�ȿ� = ��Ʈ(����(
	double dX = (endX) - (15 * (endX - startX) / distance); //�ڷ� �� ������ x
	double dY = (endY) + (15 * (startY - endY) / distance); //�ڷ� �� ������ y

																					  // ���� ����

	CPoint pts[3];

	pts[0].x = endX; //���콺 ������ġ ��
	pts[0].y = endY;

	pts[1].x = static_cast<LONG>(dX - 15 * cos(degree)); // ����
	pts[1].y = static_cast<LONG>(dY - 15 * sin(degree));

	pts[2].x = static_cast<LONG>(dX + 15 * cos(degree)); // �Ʒ���
	pts[2].y = static_cast<LONG>(dY + 15 * sin(degree));

	cPaintDc->MoveTo(pts[0].x, pts[0].y);
	cPaintDc->LineTo(pts[1].x, pts[1].y);

	cPaintDc->MoveTo(pts[0].x, pts[0].y);
	cPaintDc->LineTo(pts[2].x, pts[2].y);


	//������� ȭ��ǥ �������� ������

	dX = (startX) + (15 * (endX - startX) / distance); //�ڷ� �� ������ x
	dY = (startY) - (15 * (startY - endY) / distance); //�ڷ� �� ������ y

	double dX2 = (startX) - ((endX - startX) / distance);
	double dY2 = (startY) + ((startY - endY) / distance);

	CPoint pts2[4];

	pts2[0].x = static_cast<LONG>(dX - 15 * cos(degree)); // ����
	pts2[0].y = static_cast<LONG>(dY - 15 * sin(degree));

	pts2[1].x = static_cast<LONG>(dX2); //���콺 ó�� ��
	pts2[1].y = static_cast<LONG>(dY2);

	pts2[2].x = static_cast<LONG>(dX + 15 * cos(degree)); // �Ʒ���
	pts2[2].y = static_cast<LONG>(dY + 15 * sin(degree));

	pts2[3].x = static_cast<LONG>(dX) + static_cast<LONG>(15 * (endX - startX) / distance); // ����
	pts2[3].y = static_cast<LONG>(dY) - static_cast<LONG>(15 * (startY - endY) / distance);

	cPaintDc->SelectObject(&white);
	cPaintDc->Polygon(pts2, 4);
	cPaintDc->SelectObject(oldBrush);
	myBrush.DeleteObject();
}

void DrawingVisitor::Visit(Composition *composition, CDC* cPaintDc) {

	Long startX = composition->GetX();
	Long  startY = composition->GetY();;
	Long endX = composition->GetWidth();
	Long endY = composition->GetHeight();
	//cout << "�ռ����" << " " << x << " " << y << " " << width << " " << height << endl;

	cPaintDc->MoveTo(startX, startY);
	cPaintDc->LineTo(endX, endY);

	CBrush black(RGB(000, 000, 000));
	CBrush myBrush;
	myBrush.CreateSolidBrush(RGB(255, 255, 255));
	CBrush *oldBrush = cPaintDc->SelectObject(&myBrush);


	double degree = atan2(endX - startX, startY - endY); // ����

	double distance = sqrt(pow(endX - startX, 2) + pow(startY - endY, 2));

	double dX = (startX) + (15 * (endX - startX) / distance); //�ڷ� �� ������ x
	double dY = (startY) - (15 * (startY - endY) / distance); //�ڷ� �� ������ y

	double dX2 = (startX) - ((endX - startX) / distance);
	double dY2 = (startY) + ((startY - endY) / distance);

	CPoint pts2[4];

	pts2[0].x = static_cast<LONG>(dX - 15 * cos(degree)); // ����
	pts2[0].y = static_cast<LONG>(dY - 15 * sin(degree));

	pts2[1].x = static_cast<LONG>(dX2); //���콺 ó�� ��
	pts2[1].y = static_cast<LONG>(dY2);

	pts2[2].x = static_cast<LONG>(dX + 15 * cos(degree)); // �Ʒ���
	pts2[2].y = static_cast<LONG>(dY + 15 * sin(degree));

	pts2[3].x = static_cast<LONG>(dX) + static_cast<LONG>(15 * (endX - startX) / distance); // ����
	pts2[3].y = static_cast<LONG>(dY) - static_cast<LONG>(15 * (startY - endY) / distance);

	cPaintDc->SelectObject(&black);
	cPaintDc->Polygon(pts2, 4);
	cPaintDc->SelectObject(oldBrush);
	myBrush.DeleteObject();
}

void DrawingVisitor::Visit(Compositions *compositions, CDC* cPaintDc) {

	Long startX = compositions->GetX();
	Long  startY = compositions->GetY();;
	Long endX = compositions->GetWidth();
	Long endY = compositions->GetHeight();
	//cout << "���տ������" << " " << x << " " << y << " " << width << " " << height << endl;

	cPaintDc->MoveTo(startX, startY);
	cPaintDc->LineTo(endX, endY);

	CBrush black(RGB(000, 000, 000));
	CBrush myBrush;
	myBrush.CreateSolidBrush(RGB(255, 255, 255));
	CBrush *oldBrush = cPaintDc->SelectObject(&myBrush);

	double degree = atan2(endX - startX, startY - endY); // ����

	double distance = sqrt(pow(endX - startX, 2) + pow(startY - endY, 2));
	// ��Ʈ�ȿ� = ��Ʈ(����(
	double dX = (endX) - (15 * (endX - startX) / distance); //�ڷ� �� ������ x
	double dY = (endY) + (15 * (startY - endY) / distance); //�ڷ� �� ������ y

																					  // ���� ����
	CPoint pts[3];

	pts[0].x = endX; //���콺 ������ġ ��
	pts[0].y = endY;

	pts[1].x = static_cast<LONG>(dX - 15 * cos(degree)); // ����
	pts[1].y = static_cast<LONG>(dY - 15 * sin(degree));

	pts[2].x = static_cast<LONG>(dX + 15 * cos(degree)); // �Ʒ���
	pts[2].y = static_cast<LONG>(dY + 15 * sin(degree));

	cPaintDc->MoveTo(pts[0].x, pts[0].y);
	cPaintDc->LineTo(pts[1].x, pts[1].y);

	cPaintDc->MoveTo(pts[0].x, pts[0].y);
	cPaintDc->LineTo(pts[2].x, pts[2].y);

	//������� ȭ��ǥ �������� ������
	distance = sqrt(pow(endX - startX, 2) + pow(startY - endY, 2));

	dX = (startX) + (15 * (endX - startX) / distance); //�ڷ� �� ������ x
	dY = (startY) - (15 * (startY - endY) / distance); //�ڷ� �� ������ y

	double dX2 = (startX) - ((endX - startX) / distance);
	double dY2 = (startY) + ((startY - endY) / distance);

	CPoint pts2[4];

	pts2[0].x = static_cast<LONG>(dX - 15 * cos(degree)); // ����
	pts2[0].y = static_cast<LONG>(dY - 15 * sin(degree));

	pts2[1].x = static_cast<LONG>(dX2); //���콺 ó�� ��
	pts2[1].y = static_cast<LONG>(dY2);

	pts2[2].x = static_cast<LONG>(dX + 15 * cos(degree)); // �Ʒ���
	pts2[2].y = static_cast<LONG>(dY + 15 * sin(degree));

	pts2[3].x = static_cast<LONG>(dX) + static_cast<LONG>(15 * (endX - startX) / distance); // ����
	pts2[3].y = static_cast<LONG>(dY) - static_cast<LONG>(15 * (startY - endY) / distance);

	cPaintDc->SelectObject(&black);
	cPaintDc->Polygon(pts2, 4);
	cPaintDc->SelectObject(oldBrush);
	myBrush.DeleteObject();
}

DrawingVisitor::~DrawingVisitor() {
}

void DrawingVisitor::Visit(Template *object) {

	Long x = object->GetX();
	Long  y = object->GetY();;
	Long width = object->GetWidth();
	Long height = object->GetHeight();
	cout << "���ø����" << " " << x << " " << y << " " << width << " " << height << endl;

}