//TextComponent.cpp
#include"TextComponent.h"

TextComponent::TextComponent() {
}
TextComponent::TextComponent(const TextComponent& source) {
}
TextComponent::~TextComponent() {
}
