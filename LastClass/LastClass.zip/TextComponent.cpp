//TextComponent.cpp
#include"TextComponent.h"

TextComponent::TextComponent() {
}
TextComponent::TextComponent(const TextComponent& source) {
}
void TextComponent::operator= (const TextComponent& source) {
}
TextComponent::~TextComponent() {
}
