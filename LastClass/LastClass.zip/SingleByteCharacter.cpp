//SingleByteCharacter.cpp

#include "SingleByteCharacter.h"

SingleByteCharacter::SingleByteCharacter() {
	this->character = ' ';
}
SingleByteCharacter::SingleByteCharacter(char character) {
	this->character = character;
}
SingleByteCharacter::SingleByteCharacter(const SingleByteCharacter& source) {
	this->character = source.character;
}
SingleByteCharacter::~SingleByteCharacter() {
}
Character* SingleByteCharacter::Clone() const {
	return new SingleByteCharacter(*this);
}
SingleByteCharacter& SingleByteCharacter::operator=(const SingleByteCharacter& source) {
	this->character = source.character;
	return *this;
}
 
//����Ȯ�οϷ�