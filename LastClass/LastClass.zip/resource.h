//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// LastClass.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDR_TOOLBAR                     101
#define ID_BUTTON40002                  40002
#define ID_BUTTON40003                  40003
#define ID_BUTTON40001                  40004
#define ID_BUTTON40005                  40005
#define ID_BUTTON40006                  40006
#define ID_BUTTON40007                  40007
#define ID_BUTTON40008                  40008
#define ID_BUTTON40009                  40009
#define ID_BUTTON40010                  40010
#define ID_BUTTON40011                  40011
#define ID_BUTTON40012                  40012
#define ID_BUTTON40013                  40013
#define ID_BUTTON40014                  40014
#define ID_BUTTON40015                  40015

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40016
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
