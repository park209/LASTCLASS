//PrintPreviewButtonAction.cpp

#include "PrintPreviewButtonAction.h"

PrintPreviewButtonAction::PrintPreviewButtonAction() {
}

PrintPreviewButtonAction::PrintPreviewButtonAction(const PrintPreviewButtonAction& source) {
}

PrintPreviewButtonAction::~PrintPreviewButtonAction() {
}

void PrintPreviewButtonAction::ButtonPress(PrintPreview *printPreview) {
}