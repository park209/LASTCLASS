//Reception.h

#ifndef _RECEPTION_H
#define _RECEPTION_H

#include "Figure.h"
#include "WritingVisitor.h"

typedef signed long int Long;
using namespace std;

class Visitor;
class Reception :public Figure {
public:
	Reception();
	Reception(const Reception& source);
	Reception(Long x, Long y, Long width, Long height, string content);
	~Reception();

	Reception& operator = (const Reception& source);

	void Accept(Visitor& visitor, CDC *cPaintDc);

	Figure* Clone() const;

};

#endif // !_RECEPTION_H