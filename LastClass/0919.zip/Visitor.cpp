#include "Visitor.h"

Visitor::Visitor()
{
}
Visitor::~Visitor()
{
}
