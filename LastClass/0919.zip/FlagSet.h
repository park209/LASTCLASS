//FlagSet.h
#ifndef _FLAGSET_H
#define _FLAGSET_H
#endif // !_FLAGSET_H
