#pragma once
#ifndef _CHARACTER_H
#define _CHARACTER_H
#include "TextComponent.h"
typedef signed long int Long;
class Character : public TextComponent {
public:
	Character();
	Character(const Character& source);
	virtual ~Character() = 0;
	void operator = (const Character& source);
	virtual TextComponent* Clone() const = 0;
	void PrintCharacter();

};

#endif // !_CHARACTER_H
