//Text.cpp 
#include "Text.h"

Text::Text(Long cpacity) : TextComposite(cpacity) {
	this->capacity = cpacity;
	this->length = 0;
}
Text::~Text() {
}

Text::Text(const Text& source) {
	this->textComponents = source.textComponents;


	Long i = 0;
	while (i < source.length) {
		this->textComponents.Modify(i, (const_cast<Text&>(source)).textComponents[i]->Clone());
		i++;
	}
	this->capacity = source.capacity;
	this->length = source.length;
}
Long Text::Add(Row *row) {
	Long index;

	if (this->length < this->capacity) {
		index = this->textComponents.Store(this->length, row->Clone());
	}
	else {
		index = this->textComponents.AppendFromRear(row->Clone());
		this->capacity++;
	}
	this->length++;
	return index;
}

Long Text::Add(TextComponent *textComponent) {
	Long index;

	if (this->length < this->capacity) {
		index = this->textComponents.Store(this->length, textComponent);
	}
	else {
		index = this->textComponents.AppendFromRear(textComponent);
		this->capacity++;
	}
	this->length++;
	return index;
}

Row* Text::GetAt(Long index) {
	return dynamic_cast<Row*>(this->textComponents[index]);
}

TextComponent*  Text::Clone() const {
	return new Text(*this);
}

Row* Text::operator[] (Long index) {
	return dynamic_cast<Row*>(this->textComponents[index]);
}


Text& Text::operator= (const Text& source) {
	Long i = 0;
	this->textComponents = source.textComponents;

	while (i < source.length) {
		this->textComponents.Modify(i, (const_cast<Text&>(source)).textComponents.GetAt(i)->Clone());
		i++;
	}
	this->capacity = source.capacity;
	this->length = source.length;
	return *this;
}

#include <iostream>
using namespace std;
#include "SingleByteCharacter.h"
#include "DoubleByteCharacter.h"
#include "Character.h"

#include <iostream>
#include "SingleByteCharacter.h"
#include "DoubleByteCharacter.h"
#include <string>

using namespace std;

int main(int argc, char* argv[]) {
	Text object1(100);
	Row rowObject1(100);
	Long index;
	index=object1.Add(rowObject1.Clone());

	DoubleByteCharacter doubleByte("��");
	object1.GetAt(index)->Add(doubleByte.Clone());
	SingleByteCharacter single('A');
	object1.GetAt(index)->Add(single.Clone());
	DoubleByteCharacter doubleByte3("��");
	object1.GetAt(index)->Add(doubleByte3.Clone());
	DoubleByteCharacter doubleByte4("��");
	object1.GetAt(index)->Add(doubleByte4.Clone());
	SingleByteCharacter single1('B');
	object1.GetAt(index)->Add(single1.Clone());
	Row rowObject2(100);
	object1.GetAt(index)->Add(doubleByte.Clone());
	index = object1.Add(rowObject2.Clone());
	doubleByte = "��";
	object1.GetAt(index)->Add(doubleByte.Clone());
	single = 'A';
	object1.GetAt(index)->Add(single.Clone());

	Long i = 0;
	Long j ;
	while (i < object1.GetLength()) {
		j = 0;
		while (j < object1.GetAt(i)->GetLength()) {
			object1.GetAt(i)->GetAt(j)->PrintCharacter();
			j++;
		}
		i++;
}
	return 0;
}