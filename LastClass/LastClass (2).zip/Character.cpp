//Character.cpp

#include "Character.h"
#include "DoubleByteCharacter.h"
#include "SingleByteCharacter.h"
#include <iostream>
using namespace std;
Character::Character() {
}
Character::Character(const Character& source) {
}
Character::~Character() {
}
void Character::operator= (const Character& source) {
}
void Character::PrintCharacter() {
	char testDouble[3];
	if (static_cast<DoubleByteCharacter*>(this)) {
		testDouble[0] = static_cast<DoubleByteCharacter*>(this)->GetCharacters()[0];
		testDouble[1] = static_cast<DoubleByteCharacter*>(this)->GetCharacters()[1];
		testDouble[2] = '\0';
	}
	else if (static_cast<SingleByteCharacter*>(this)) {
		testDouble[0] = static_cast<SingleByteCharacter*>(this)->GetCharacter();
		testDouble[1] = '\0';
	}
	cout << testDouble << endl;
}

//Ȯ�οϷ�