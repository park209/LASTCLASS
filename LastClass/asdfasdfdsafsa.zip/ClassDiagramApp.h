
#ifndef _CLASSDIAGRAMAPP_H
#define _CLASSDIAGRAMAPP_H

#include <afxwin.h>

class ClassDiagramApp : public CWinApp {
public:
	BOOL InitInstance();
};

#endif // _CLASSDIAGRAMAPP_H