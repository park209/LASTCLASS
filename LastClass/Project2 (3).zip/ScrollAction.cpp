//ScrollAction.cpp

#include "ScrollAction.h"

ScrollAction::ScrollAction() {
}
ScrollAction::ScrollAction(const ScrollAction& source) {
}
ScrollAction::~ScrollAction() {
}
ScrollAction& ScrollAction::operator=(const ScrollAction& source) {
	return *this;
}
void ScrollAction::Scrolling(ClassDiagramForm *classDiagramForm) {
}