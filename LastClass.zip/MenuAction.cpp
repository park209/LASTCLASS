//MenuAction.cpp

#include "MenuAction.h"

MenuAction::MenuAction() {
}

MenuAction::~MenuAction() {
}

