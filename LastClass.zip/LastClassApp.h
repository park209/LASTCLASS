
#ifndef _LASTCLASSAPP_H
#define _LASTCLASSAPP_H

#include <afxwin.h>

class LastClassApp : public CWinApp {
public:  
	BOOL InitInstance();
};

#endif // _LASTCLASSAPP_H