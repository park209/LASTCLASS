//CMemoryDC.h
#ifndef _CMEMORYDC_H
#define _CMEMORYDC_H

class CMemoryDC {

};

#endif // !_CMEMORYDC_H
