//TextAreaSelected.cpp

#include "TextAreaSelected.h"
#include "TextEdit.h"
#include "Caret.h"
#include "Text.h"
#include "Row.h"
#include "Character.h"
#include "Figure.h"

TextAreaSelected::TextAreaSelected() {
}

TextAreaSelected::TextAreaSelected(const TextAreaSelected& source) {
}

TextAreaSelected::~TextAreaSelected() {
}

void TextAreaSelected::SelectTextArea(TextEdit *textEdit, CPaintDC *dc) {
	CRect rect;
	this->startCharacterIndex = 0;
	this->startRowIndex = 0;
	this->endCharacterIndex = 0;
	this->endRowIndex = 0;
	Long i;
	Long x;
	Long width = 0;
	CString str;

	CFont cFont;
	cFont.CreateFont(textEdit->GetRowHeight(), 0, 0, 0, FW_LIGHT, FALSE, FALSE, 0, DEFAULT_CHARSET,// �۲� ����
		OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "����ü");
	textEdit->SetFont(&cFont, TRUE);
	CFont *oldFont = dc->SelectObject(&cFont);
	CDC memDC;
	CBitmap *pOldBitmap;
	CBitmap bitmap;

	memDC.CreateCompatibleDC(dc);
	bitmap.CreateCompatibleBitmap(dc, textEdit->GetFigure()->GetWidth(), textEdit->GetFigure()->GetHeight());
	pOldBitmap = memDC.SelectObject(&bitmap);

	memDC.FillSolidRect(CRect(0, 0, textEdit->GetFigure()->GetWidth(), textEdit->GetFigure()->GetHeight()), RGB(255, 255, 255));
	memDC.SelectObject(cFont);

	memDC.SetTextColor(RGB(255, 255, 255));
	memDC.SetBkColor(RGB(51, 153, 255));
	memDC.SetBkMode(OPAQUE);//�ؽ�Ʈ ����� SetBkColor ���


	CString cString1;
	if (textEdit->selectedY == textEdit->caret->GetRowIndex()) { // ���ٿ��� �����°Ÿ�
		if (textEdit->selectedX < textEdit->caret->GetCharacterIndex()) {
			this->startCharacterIndex = textEdit->selectedX;
			this->startRowIndex = textEdit->selectedY;
			this->endCharacterIndex = textEdit->caret->GetCharacterIndex();
			this->endRowIndex = textEdit->caret->GetRowIndex();
		}
		else {
			this->startCharacterIndex = textEdit->caret->GetCharacterIndex();
			this->startRowIndex = textEdit->caret->GetRowIndex();
			this->endCharacterIndex = textEdit->selectedX;
			this->endRowIndex = textEdit->selectedY;
		}
		width = 0;
		i = startCharacterIndex;
		while (i < endCharacterIndex) { // ù��
			cString1 += textEdit->text->GetAt(startRowIndex)->GetAt(i)->MakeCString();
			str = textEdit->text->GetAt(startRowIndex)->GetAt(i)->MakeCString();
			if (str == "\t") {
				str = "        ";
			}
			width += dc->GetTextExtent(str).cx;
			i++;
		}
		x = 5;
		i = 0;
		while (i < startCharacterIndex) { // �����ٿ��� ĳ�����ε������� �ʺ� ���Ѵ�
			str = textEdit->text->GetAt(startRowIndex)->GetAt(i)->MakeCString();
			if (str == "\t") {
				str = "        ";
			}
			x += dc->GetTextExtent(str).cx;
			i++;
		}
		rect = { 0, 0, x + width, startRowIndex * textEdit->rowHeight + textEdit->rowHeight +5 };
		memDC.DrawText(cString1, rect, DT_EXPANDTABS | DT_TABSTOP | 0x0800);
		dc->BitBlt(x, startRowIndex * textEdit->rowHeight+5, x + width-32, startRowIndex * textEdit->rowHeight + textEdit->rowHeight+5, &memDC, 0, 0, SRCCOPY);

		textEdit->copyBuffer = cString1;
	}
	else { // ������ �����̸�
		if (textEdit->selectedY < textEdit->caret->GetRowIndex()) {
			this->startCharacterIndex = textEdit->selectedX;
			this->startRowIndex = textEdit->selectedY;
			this->endCharacterIndex = textEdit->caret->GetCharacterIndex();
			this->endRowIndex = textEdit->caret->GetRowIndex();
		}
		else {
			this->startCharacterIndex = textEdit->caret->GetCharacterIndex();
			this->startRowIndex = textEdit->caret->GetRowIndex();
			this->endCharacterIndex = textEdit->selectedX;
			this->endRowIndex = textEdit->selectedY;
		}
		width = 0;
		i = startCharacterIndex;
		while (i < textEdit->text->GetAt(this->startRowIndex)->GetLength()) { // ù��
			cString1 += textEdit->text->GetAt(this->startRowIndex)->GetAt(i)->MakeCString();
			str = textEdit->text->GetAt(this->startRowIndex)->GetAt(i)->MakeCString();
			if (str == "\t") {
				str = "        ";
			}
			width += dc->GetTextExtent(str).cx;
			i++;
		}
		cString1 += "\r\n";
		x = 5;
		i = 0;
		while (i < this->startCharacterIndex) { // �����ٿ��� ĳ�����ε������� �ʺ� ���Ѵ�
			str = textEdit->text->GetAt(this->startRowIndex)->GetAt(i)->MakeCString();
			if (str == "\t") {
				str = "        ";
			}
			x += dc->GetTextExtent(str).cx;
			i++;
		}
		rect = { 0, 0, x + width, this->startRowIndex * textEdit->rowHeight + textEdit->rowHeight + 5 };
		memDC.DrawText(cString1, rect, DT_EXPANDTABS | DT_TABSTOP | 0x0800);
		dc->BitBlt(x, this->startRowIndex * textEdit->rowHeight + 5, x + width, this->startRowIndex * textEdit->rowHeight + textEdit->rowHeight + 5, &memDC, 0, 0, SRCCOPY);

		string string2; // �߰�
		if (this->startRowIndex + 1 < this->endRowIndex) {
			i = this->startRowIndex + 1;
			while (i < this->endRowIndex) {
				string2 += textEdit->text->GetAt(i)->PrintRowString().c_str();
				string2 += "\r\n";
				i++;
			}
			x = 5;
			rect = { 0, 0, textEdit->GetFigure()->GetX()+ textEdit->GetFigure()->GetWidth(),
				(this->endRowIndex - 1) * textEdit->rowHeight + textEdit->rowHeight + 5 };
			memDC.DrawText(string2.c_str(), rect, DT_EXPANDTABS | DT_TABSTOP | 0x0800);
			dc->BitBlt(x, (this->startRowIndex + 1) * textEdit->rowHeight + 5, textEdit->GetFigure()->GetX() + textEdit->GetFigure()->GetWidth(),
				(this->endRowIndex - 1) * textEdit->rowHeight + textEdit->rowHeight + 5, &memDC, 0, 0, SRCCOPY);
		}

		CString cString3;
		width = 0;
		i = 0;
		while (i < this->endCharacterIndex) { // ����
			cString3 += textEdit->text->GetAt(this->endRowIndex)->GetAt(i)->MakeCString();
			str = textEdit->text->GetAt(this->endRowIndex)->GetAt(i)->MakeCString();
			if (str == "\t") {
				str = "        ";
			}
			width += dc->GetTextExtent(str).cx;
			i++;
		}
		x = 5;
		i = 0;
		rect = { 0, 0, x + width, this->endRowIndex * textEdit->rowHeight + textEdit->rowHeight + 5 };
		memDC.DrawText(cString3, rect, DT_EXPANDTABS | DT_TABSTOP | 0x0800);
		dc->BitBlt(x, this->endRowIndex * textEdit->rowHeight + 5, x + width, this->endRowIndex * textEdit->rowHeight + textEdit->rowHeight + 5, &memDC, 0, 0, SRCCOPY);

		textEdit->copyBuffer = cString1 + string2.c_str() + cString3; // �Ӽ��� ����
	}


	memDC.SelectObject(pOldBitmap);
	bitmap.DeleteObject();
	memDC.SelectObject(cFont);
	dc->SelectObject(oldFont);
	cFont.DeleteObject(); // ��Ʈ
	memDC.DeleteDC();
}