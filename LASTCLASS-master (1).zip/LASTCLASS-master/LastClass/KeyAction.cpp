//KeyAction.cpp

#include "KeyAction.h"

KeyAction::KeyAction() {
}
KeyAction::~KeyAction() {
}